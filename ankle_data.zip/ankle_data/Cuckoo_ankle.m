clc;
clear;
close all;

D = 4; %% Number of variables (a,alpha)
lb = [-4.736347965398963e-05  3.515592492211810e-06  -0.207274832109640 4.928078378088391e-05]; %% Lower bound of variables
ub = [-4.218710968384586e-05 3.946956658615670e-06  -0.100971968671745 5.532754951493384e-05]; %% Uper bound of variables
N = 20; %% Population size
n = N;
pa = 0.25; %% Probability of discover allien eggs
max_iter = 100; %% Maximum number of iteration

%% Generate initial population

for i = 1:N
    for j = 1:D
        nest(i,j) = lb(:,j)+rand.*(ub(:,j)-lb(:,j));
    end
end

fx = ankle(nest);

landa = 1.5;
sigma = (gamma(1+landa)*sin(pi*landa/2)/(gamma((1+landa)/2)*landa*2^((landa-1)/2)))^(1/landa);

%% Cuckoo search loop

for iter = 1:max_iter
    [fnv,indf] = min(fx);
    X_best = nest(indf,:);
    
    for j = 1:N
        s = nest(j,:);
        X = s;
        %% Levy flight
        u = randn(size(s))*sigma;
        v = randn(size(s));
        step = u./abs(v).^(1/landa);
        X_new = X + randn(size(s)).*0.01.*step.*(X - X_best);
        
        %% Check
        for k = 1:size(X_new,2)
            if X_new(k) > ub(k)
                X_new(k) = ub(k);
            elseif X_new(k) < lb(k)
                X_new(k) = lb(k);
            end
        end
        f_new = ankle(X_new);
        if f_new < fx(j,:)
            nest(j,:) = X_new;
            fx(j,:) = f_new;
        end
    end
    
    %% Current best
    [fmin,K1] = min(fx);
    X_best = nest(K1,:);
    
    r = rand(size(nest)) < pa;
    r_step = rand*(nest(randperm(n),:) - nest(randperm(n),:));
    nest_new = nest + r_step.* r;
    
    %% Check
    for ii = 1:size(nest,1)
        ns = nest_new(ii,:);
        for kk = 1:size(ns,2)
        if ns(kk) > ub(kk)
            ns(kk) = ub(kk);
        elseif ns(kk) < lb(kk)
            ns(kk) = lb(kk);
        end
        end
        nest_new(ii,:) = ns;
        
        f_new = ankle(ns);
        if f_new < fx(ii,:)
            nest(ii,:) = ns;
            fx(ii,:) = f_new;
        end
    end
    
    %% Memory
    [optval,optind] = min(fx);
    fx_best(iter) = optval; %% best objective function value
    Xg_best(iter,:) = nest(optind,:); %% best solution
    
    disp(['iteration', num2str(iter) ...
        ':Best Cost = ' num2str(fx_best(iter))]);
    
    
end

plot(fx_best, 'LineWidth',2,'color','k'); 
title('Cuckoo Search Optimization','color','b','FontSize',12,'FontWeight','bold','FontName','Cambria')
xlabel('iteration number','color','b','FontSize',10,'FontWeight','bold','FontName','Cambria')
ylabel('Optimum Value','color','b','FontSize',10,'FontWeight','bold','FontName','Cambria')
grid on


