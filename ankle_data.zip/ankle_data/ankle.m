function RM = ankle(X)
%% foot segment
M_total = 70;
m_foot = 0.0145*M_total;
L_foot = 0.2;
L_od3 = 0.5*L_foot;
R_foot = 0.475*L_foot;
g = 9.81;
I_foot = m_foot*R_foot^2;
L_od2 = 0.567*0.49;
Rx2 = 0;
Ry2 = 100.74;
M2 = 38.66;

ax_ankle = X(:,1);       %% acceleration x
ay_ankle = X(:,2);       %% acceleration y
teta_ankle = X(:,3);
alpha_ankle = X(:,4);    %% angular acceleration

Rx3 = m_foot*ax_ankle + Rx2
Ry3 = m_foot*g + m_foot*ay_ankle + Ry2
M3 = L_od3.*cos(teta_ankle).*Ry2 + L_od3.*sin(teta_ankle).*Rx2 + I_foot*alpha_ankle + ...
L_od2.*cos(teta_ankle).*Ry2 + L_od2.*sin(teta_ankle).*Rx2 + M2

RM = Rx3.^2 + Ry3.^2 + M3.^2;

end